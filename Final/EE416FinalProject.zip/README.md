# Group Name:
Frendy Lio
Dino Mariano
Keenan Lee

# Accuracy
90.6%
